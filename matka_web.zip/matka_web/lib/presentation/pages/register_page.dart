import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:matka_web/app_colors.dart';
import 'package:matka_web/constants.dart';
import 'package:http/http.dart' as http;
import 'package:matka_web/presentation/pages/home_page/screens/home_page.dart';
import 'package:matka_web/presentation/pages/login_page.dart';
import 'package:matka_web/storage/user_info.dart';

class RegisterPage extends StatefulWidget {
    RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController name = TextEditingController();
  TextEditingController number = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController memberId = TextEditingController();
  TextEditingController code = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: Container(
          width: 400,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                height: 100,
                width: 100,
                "assets/logo/logo.png",
              ),
                const SizedBox(height: 16,),
                const Text("Register"),
                const SizedBox(height: 8,),
                 TextField(
                  controller: name,
                decoration: const InputDecoration(
                  hintText: 'Name',
                  prefixIcon: Icon(Icons.phone),
                  border: OutlineInputBorder()
                ),
              ),
                const SizedBox(height: 8,),
                TextField(
                  controller: number,
                decoration: const InputDecoration(
                  hintText: 'Mobile Number',
                  prefixIcon: Icon(Icons.phone),
                  border: OutlineInputBorder()
                ),
              ),
                const SizedBox(height: 8,),
                TextField(
                obscureText: true,
                  controller: password,
                 decoration: const InputDecoration(
                  hintText: 'Password',
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder()
                ),
              ),
                 const SizedBox(height: 8,),
                 TextField(
                   controller: memberId,
                 decoration: const InputDecoration(
                  hintText: "User Id",
                  prefixIcon: Icon(Icons.password_sharp),
                  border: OutlineInputBorder()
                ),
              ),
                const SizedBox(height: 8,),
                TextField(
                  controller: code,
                decoration: const InputDecoration(
                    hintText: 'Referral Code',
                    prefixIcon: Icon(Icons.password_sharp),
                    border: OutlineInputBorder()
                ),
              ),
                const SizedBox(height: 16,),
              ElevatedButton(
                onPressed: createUser,
                  style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  minimumSize: const Size(double.infinity, 40),
                ),
                child:   const Text("Register"),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                    const Text("Already have an account?"),
                  TextButton(onPressed: (){
                    Get.to(()=>const LoginPage());
                  }, child:   const Text("Login"))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
  Future<void> createUser() async {
    final url = Uri.parse("$baseUrl/userRegistration_wotp.php");
    final body = {
      "name" : name.text.toString(),
      "mobileNum" : number.text.toString(),
      "password" : password.text.toString(),
      "member_passcode" : memberId.text.toString(),
      "referralcode" : code.text.toString() == "" ? "" : code.text.toString()
    };
    print(url);
    final headers = {
      "Content-Type": "application/x-www-form-urlencoded",// Replace with your token if required
    };
   try{


     final response = await http.post(url,body: body,headers: headers);
     if(response.statusCode == 200){
       final body = jsonDecode(response.body);
       print(body);
       if(body['status'] == "success"){
       UserInfo.storeUserInfo(body['member_id'].toString());
       Get.to(() =>  const HomePage());
       } else{
         Get.snackbar("Error", "User is already exist",backgroundColor: Colors.redAccent);
       }
     } else {
       // Handle server errors
       Get.snackbar("Alert", "Something went wrong");
       // print('Server error: ${response.statusCode} - ${response.reasonPhrase}');
     }

   } catch (e){
     print(e);
   }
  }
}