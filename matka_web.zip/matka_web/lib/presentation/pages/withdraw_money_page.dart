import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:matka_web/golbal_controller.dart';

import '../../app_colors.dart';
import '../../constants.dart';
import '../../storage/user_info.dart';

class WithdrawMoneyPage extends StatefulWidget {
  const WithdrawMoneyPage({super.key});

  @override
  State<WithdrawMoneyPage> createState() => _WithdrawMoneyPageState();
}

class _WithdrawMoneyPageState extends State<WithdrawMoneyPage> {
  TextEditingController amount = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: Text("Withdraw Money"),
      ),
      body: Center(
        child: Container(
          margin: EdgeInsets.all(10),
          width: 400,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Withdrawal point"),
              TextField(
                controller: amount,
                decoration: InputDecoration(
                    hintText: "Withdraw Points", border: OutlineInputBorder()),
              ),
              Text(
                  "Minimum Withdrawal Amount ₹${GlobalController.adminModel.value?.minWithdrawalRate}"),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white),
                    onPressed: () {
                      withdrawMoney();
                    },
                    child: Text("Send Request")),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(5),
                margin: EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(color: Colors.black, width: 1),
                ),
                child: Text("Withdrawal Time :- 6:00 AM - 8:00 PM"),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(5),
                margin: EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(color: Colors.black, width: 1),
                ),
                child: Text("Maximum hold amount :- 0"),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> withdrawMoney() async {
    final url = Uri.parse("$baseUrl/withdrawalrequest.php");
    final id = await UserInfo.getUserInfo() ?? '';
    final body = {"member_id": id, "amount": amount.text.toString()};
    print(url);
    final headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      // "X-Requested-With": "XMLHttpRequest",
    };
    try {
      final response = await http.post(
        url,
        body: body,
        headers: headers,
      );
      // print(response);

      if (response.statusCode == 200) {
        Map<String, dynamic> data = {};
        // Successful request, process the response
        try {
          data = jsonDecode(response.body);
          print(data['status'].toString());

          if (data['status'].toString().compareTo("Low Wallet Balance") == 0) {
            Get.snackbar("Alert", "Low Wallet Balance",
                backgroundColor: Colors.redAccent);
          } else {
            Get.snackbar("Success", "Successfully Withdrawal",
                backgroundColor: Colors.green);
          }
          // Process data
        } catch (e) {
          print('Error decoding JSON: $e');
          // Get.snackbar('Error', 'Failed to decode data');
        }
      } else {
        // Handle server errors
        Get.snackbar("Alert", "Something went wrong");
        // print('Server error: ${response.statusCode} - ${response.reasonPhrase}');
      }
    } catch (e) {
      // Handle exceptions
      print('Request failed with error: $e');
    }
  }
}
