import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:matka_web/constants.dart';
import 'package:matka_web/presentation/pages/register_page.dart';

import '../../alerts.dart';
import '../../app_colors.dart';
import '../../global_functions.dart';
import '../../storage/user_info.dart';
import 'home_page/screens/home_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController number = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: Container(
          width: 400,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                height: 100,
                width: 100,
                "assets/logo/logo.png",
              ),
              const SizedBox(
                height: 16,
              ),
              const Text("Register"),
              const SizedBox(
                height: 8,
              ),
              TextField(
                controller: number,
                decoration: const InputDecoration(
                    hintText: 'Mobile Number',
                    prefixIcon: Icon(
                      Icons.phone,
                      color: Colors.white,
                    ),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white))),
              ),
              const SizedBox(
                height: 8,
              ),
              TextField(
                obscureText: true,
                controller: password,
                decoration: const InputDecoration(
                    hintText: 'Password',
                    prefixIcon: Icon(Icons.lock, color: Colors.white),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.white))),
              ),
              const SizedBox(
                height: 16,
              ),
              ElevatedButton(
                onPressed: userLogin,
                child: const Text("Login"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  minimumSize: const Size(double.infinity, 40),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                      onPressed: () {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (context) => RegisterPage(),
                        ));
                      },
                      child: const Text("Sign Up?")),
                  const Text("|"),
                  TextButton(
                      onPressed: () {}, child: const Text("Forgot password?"))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> userLogin() async {
    final url = Uri.parse("$baseUrl/userLogin.php");

    final body = {
      "mobileNum": number.text.toString(),
      "password": password.text.toString(),
    };

    final headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      // // "X-Requested-With": "XMLHttpRequest",
    };
    try {
      final response = await http.post(
        url,
        body: body,
        headers: headers,
      );

      if (response.statusCode == 200) {
        Map<String, dynamic> data = Map();
        // Successful request, process the response
        try {
          data = jsonDecode(response.body);
          //

          if (data['status'].toString().compareTo("success") == 0) {
            UserInfo.storeUserInfo(data['member_id'] ?? '');
            GlobalFunctions.getProfileDetails();
            Timer(
              const Duration(seconds: 1),
              () {
                Get.to(() => const HomePage());
              },
            );
          } else {
            CustomAlert.error("Alert", "Please Enter Valid Details!");
          }
          //   // Process data
        } catch (e) {
          CustomAlert.error("Error", "Failed to decode data");
        }
      } else {
        // Handle server errors
        CustomAlert.error("Alert", "Something went wrong");
        //
      }
    } catch (e) {
      // Handle exceptions
    }
  }
}
