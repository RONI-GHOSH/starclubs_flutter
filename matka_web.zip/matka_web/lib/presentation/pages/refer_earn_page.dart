import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:matka_web/constants.dart';

import '../../app_colors.dart';
import '../../storage/user_info.dart';

class ReferEarnPage extends StatefulWidget {
  const ReferEarnPage({super.key});

  @override
  State<ReferEarnPage> createState() => _ReferEarnPageState();
}

class _ReferEarnPageState extends State<ReferEarnPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getReferralDetails();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: Text("Refer & Earn"),
      ),
      body: Center(
        child: Container(
          width: 400,
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                color: Colors.black,
                child: Container(
                    width: 400,
                    height: 200,
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 16,
                        ),
                        Obx(
                          () => Text(
                            "Refferl Code :   ${_ReferralDetails.code.value}",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 22),
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        TextButton(
                            onPressed: () {},
                            child: Text(
                              "Share",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22),
                            )),
                        const SizedBox(
                          height: 8,
                        ),
                        Text(
                          "Refer & Earn upto 10% on every Bet.",
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: ElevatedButton(
                              style: ButtonStyle(
                                  backgroundColor:
                                      WidgetStatePropertyAll(Colors.red)),
                              onPressed: () {
                                Clipboard.setData(ClipboardData(
                                        text: _ReferralDetails.code.value))
                                    .then(
                                  (value) {
                                    Get.snackbar(
                                        "Success", "Copied to clipboard",
                                        backgroundColor: Colors.green);
                                  },
                                );
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.copy,
                                    color: Colors.white,
                                  ),
                                  Text(
                                    "Copy to clipboard",
                                    style: TextStyle(color: Colors.white),
                                  )
                                ],
                              )),
                        ),
                      ],
                    )),
              ),
              const SizedBox(
                height: 16,
              ),
              const Text(
                "Referral List",
                style: TextStyle(color: Colors.black, fontSize: 18),
              ),
              const SizedBox(
                height: 8,
              ),
              Obx(
                () => _ReferralDetails.memberList.isEmpty
                    ? Center(
                        child: Text("No Referrals"),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: _ReferralDetails.memberList.length,
                        itemBuilder: (context, index) {
                          MemberList member =
                              _ReferralDetails.memberList[index];
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Text(member.referrerId),
                              Text(member.referrerName),
                            ],
                          );
                        },
                      ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getReferralDetails() async {
    _ReferralDetails.code.value = "";
    _ReferralDetails.memberList.clear();

    final url = Uri.parse("$baseUrl/memberReferralDetails.php");
    final id = await UserInfo.getUserInfo() ?? '';
    final body = {"member_id": id};
    print(url);
    final headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      // "X-Requested-With": "XMLHttpRequest",
    };
    try {
      final response = await http.post(
        url,
        body: body,
        headers: headers,
      );

      if (response.statusCode == 200) {
        Map<String, dynamic> data = Map();
        // Successful request, process the response
        try {
          data = jsonDecode(response.body);
          print(data);
          _ReferralDetails.code.value = data['referreralcode'].toString();
          final list = data['member_details'] as List;
          _ReferralDetails.memberList.value = list
              .map(
                (e) => MemberList.fromJson(e),
              )
              .toList();
          // Process data
        } catch (e) {
          print('Error decoding JSON: $e');
          // Get.snackbar('Error', 'Failed to decode data');
        }
      } else {
        // Handle server errors
        Get.snackbar("Alert", "Something went wrong");
        // print('Server error: ${response.statusCode} - ${response.reasonPhrase}');
      }
    } catch (e) {
      // Handle exceptions
      print('Request failed with error: $e');
    }
  }
}

class _ReferralDetails extends GetxController {
  static RxString code = "".obs;
  static RxList memberList = [].obs;
}

class MemberList {
  final String referrerId;
  final String referrerName;

  MemberList({
    required this.referrerId,
    required this.referrerName,
  });

  // Factory method to create a Referrer instance from a JSON map
  factory MemberList.fromJson(Map<String, dynamic> json) {
    return MemberList(
      referrerId: json['referrer_id'],
      referrerName: json['referrer_name'],
    );
  }

  // Method to convert a Referrer instance to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'referrer_id': referrerId,
      'referrer_name': referrerName,
    };
  }
}
