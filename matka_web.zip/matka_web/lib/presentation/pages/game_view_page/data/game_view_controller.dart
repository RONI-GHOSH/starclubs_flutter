import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:intl/intl.dart';

import '../../../../models/lottry_model.dart';
import '../../../../models/tab_games_model.dart';

class GameViewController{
  static Rx<TabGamesModel> tabGames = TabGamesModel(marketId: '', marketName: '', list: [], status: '').obs;
  static RxString crossingDate = "".obs;
  static updateDate(){
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('EEEE, MMMM d yyyy').format(now);
    crossingDate.value = formattedDate; // Output: Friday, August 16 2024
  }

  static RxList<dynamic> lotteries = [].obs;
  static updateLotteries(String first,String second,String amount){
    Set<String> hashSet = <String>{};
    for (int i = 0; i < first.length; i++) {
      String bet = first[i]; // Single digit
      hashSet.add(bet);
    }

    // Generate two-digit combinations from first and secondNum
    for (int i = 0; i < first.length; i++) {
      for (int j = 0; j < second.length; j++) {
        String bet = '${first[i]}${second[j]}';
        hashSet.add(bet); // Add the two-digit number directly without leading zeros
      }
    }

    print(hashSet);
    // Convert the HashSet to a list of CrossingModel instances and sort it
    lotteries.value = hashSet.map((e) {
      return LotteryModel(
        lotteryNumber: e,
        lotteryAmount: int.parse(amount),
      );
    },).toList();

    print(lotteries);
    lotteries.sort((a, b) => a.lotteryAmount.compareTo(b.lotteryAmount)); // Sort the list by bet

  }
}
