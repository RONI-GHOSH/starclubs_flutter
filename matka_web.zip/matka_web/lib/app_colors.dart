import 'dart:ui';

class AppColors{
  static const Color primary = Color.fromARGB(255, 255, 168, 8);
}