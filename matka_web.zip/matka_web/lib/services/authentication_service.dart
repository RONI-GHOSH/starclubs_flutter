// import 'dart:convert';
//
// import 'package:http/http.dart' as http;
//
// class AuthenticationService {
//   static Future<void> signUp(String name , )
// }
