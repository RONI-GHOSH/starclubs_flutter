// const baseUrl = "https://cors-anywhere.herokuapp.com/https://hmroyal.online/hmroyal/api";
const baseUrl = "https://hmroyal.online/betcircle/api";